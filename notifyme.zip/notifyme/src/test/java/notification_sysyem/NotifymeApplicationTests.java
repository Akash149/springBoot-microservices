package notification_sysyem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotifymeApplicationTests {

	@Test
	void contextLoads() {
	}

}
