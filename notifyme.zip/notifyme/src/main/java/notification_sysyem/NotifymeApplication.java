package notification_sysyem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotifymeApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotifymeApplication.class, args);
	}

}
