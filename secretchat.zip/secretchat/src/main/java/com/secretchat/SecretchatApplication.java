package com.secretchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecretchatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecretchatApplication.class, args);
	}

}
